1) Right click on the folder that contains the photos to roll.
2) Select the "Snap Roll" option from the right click menu.

The photos will start rolling back to the default alignment.
You can open the folder and check the photos being rolled.
It prompts a message box after successfully rolling the images.