#This code rotates the images as per laptop/tv screens

from PIL import Image
import os, sys
import re
import ctypes

getDir = str(sys.argv[1])
setDir = getDir

print(getDir)

foundFlag = 0

def Mbox(title, text, style):
    ctypes.windll.user32.MessageBoxW(0, text, title, style)
    
for folderName, subFolders, fileNames in os.walk(getDir):
    for filename in fileNames:
        if re.search('.jpg|.jpeg', filename, re.I):
            foundFlag = 1
            path = folderName + '\\' + filename
            img = Image.open(path)
            img_exif = img._getexif()
            if re.search('None', str(img_exif)):
                continue
            else:
                img_orientation = img_exif[274]
            #width, height = img.size
            # Rotate depending on orientation.
            print(filename)
            print(img_orientation)
            if img_orientation == 1:
               img.rotate(-180, expand=True).save(path)
            if img_orientation == 3:
               img.rotate(180, expand=True).save(path)
            if img_orientation == 6:
               img.rotate(-90, expand=True).save(path)
            if img_orientation == 8:
                img.rotate(90, expand=True).save(path)

if foundFlag == 1:
    Mbox('Snap Roll', 'Completed !!!', 0)
else:
    Mbox('Snap Roll', 'No snap to roll !!!', 0)
